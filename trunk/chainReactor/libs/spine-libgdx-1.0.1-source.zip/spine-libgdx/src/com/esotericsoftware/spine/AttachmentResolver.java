
package com.esotericsoftware.spine;

public interface AttachmentResolver {
	public void resolve (Attachment attachment);
}
